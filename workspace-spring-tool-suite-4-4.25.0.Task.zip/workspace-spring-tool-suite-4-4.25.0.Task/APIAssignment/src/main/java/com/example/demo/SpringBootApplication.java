package com.example.demo;

public @interface SpringBootApplication {
	public static void main(String[] args) {
        SpringApplication.run(ApiApplication.class, args);
    }

}
