/**
 * 
 */
/**
 * 
 */
module APIAssignment {
	requires java.desktop;
	requires java.xml;
	requires jdk.compiler;
	requires jdk.javadoc;
}